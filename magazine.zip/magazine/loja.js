function produtos(prod){
    let num = parseInt(prod)
    let preco;
    let qtd;

    switch(num){
        case 1:
            preco = parseFloat(document.querySelector("#preco1").value);
            qtd = parseInt(document.querySelector("#qtd1").value);
            break;
        case 2:
            preco = parseFloat(document.querySelector("#preco2").value);
            lqtd = parseInt(document.querySelector("#qtd2").value);
            break;
        case 3:
            preco = parseFloat(document.querySelector("#preco3").value);
            lqtd = parseInt(document.querySelector("#qtd3").value);
            break;
        case 4:
            preco = parseFloat(document.querySelector("#preco4").value);
            lqtd = parseInt(document.querySelector("#qtd4").value);
            break;
        case 5:
            preco = parseFloat(document.querySelector("#preco5").value);
            lqtd = parseInt(document.querySelector("#qtd5").value);
            break;
        case 6:
            preco = parseFloat(document.querySelector("#preco6").value);
            lqtd = parseInt(document.querySelector("#qtd6").value);
            break;

        default: alert("Não encontrado.")
    };

    let total = preco * qtd;
    alert("Valor total: " + total);
}